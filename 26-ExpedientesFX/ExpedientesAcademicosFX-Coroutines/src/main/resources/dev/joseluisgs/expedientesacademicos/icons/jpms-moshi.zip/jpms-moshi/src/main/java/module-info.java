module jpms.moshi.main {
    requires kotlin.stdlib;
    requires com.squareup.moshi;
    requires com.squareup.moshi.kotlin;
}