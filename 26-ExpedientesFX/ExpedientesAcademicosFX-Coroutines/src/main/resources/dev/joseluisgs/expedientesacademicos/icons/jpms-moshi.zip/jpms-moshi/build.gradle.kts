plugins {
    kotlin("jvm") version "1.3.72"
    id("org.javamodularity.moduleplugin") version "1.7.0"
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    implementation(kotlin("stdlib"))
    implementation("com.squareup.moshi:moshi-kotlin:1.10.0-SNAPSHOT")
}