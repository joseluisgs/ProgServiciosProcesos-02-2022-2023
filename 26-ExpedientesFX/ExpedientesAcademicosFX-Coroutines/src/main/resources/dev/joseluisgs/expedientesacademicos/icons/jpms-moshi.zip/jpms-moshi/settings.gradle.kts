rootProject.name = "jpms-moshi"

